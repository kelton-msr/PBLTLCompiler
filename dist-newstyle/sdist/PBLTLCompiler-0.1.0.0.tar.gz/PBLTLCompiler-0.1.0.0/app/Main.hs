module Main where
import Data.List (intersperse)
import Control.Monad.State.Strict
import System.Environment (getArgs)
-- TODO updating the others to keep track of boxes, 
-- adding parser for PBLTL, calulcating what variables must be introduced (just c ?), stringing together with main function.
-- slightly longer term: Take in original spec to check for name collisions/mend the spec directly.
-- For now we will just emit with the currently chosen names and let the programmer add the ammendments.
-- Output will be TLA+ definitions for a new formula.


-- This deals with the full set of PBLTL formulas, with three exceptions
-- 1. Currently there is no way of having implications where there is a bounded diamond on the left hand side.
-- There some technical details that make the approach used here not work all the way, in particular involving the gnarly case where
-- the bound on the lhs is greater than the bound on the rhs. 
-- 2. There is no way to translate embedded implications with temporal operators. E.g [](P => [](Q => <>(<=n) R))
-- 3. There is no way to express the probability check on the outside within a TLA+ formula.
-- That needs to be handled seperatly.

-- For a bit more details on PBLTL, see the readme.

-- I was expecting this to be more or less stateless when writing this but I forgot about names.
-- It also appears to be necessary to keep track of if a wff is under a box,
-- In particular to handle updating the counter.
type CompM a = State ([String],Int,Bool) a

-- internal syntactic representation for (PB)LTL formulas
-- PBLTL being this modal logic that has bounded diamonds and one probability check on the outside
-- 
-- Bounded Diamonds only for now
-- Would probably not be a huge deal to add unbounded diamonds, but lets keep it simple for now.
-- Probably need to add some sort of operators syntax here to deal with TLA+ things.
data LTLForm = LBox LTLForm 
             | LDiamond Int LTLForm 
             | LAnd LTLForm LTLForm 
             | LImplies LTLForm LTLForm 
             | LAtom String 
             | LOp String [LTLForm]
             | LNeg LTLForm

instance Show LTLForm where
    show (LBox a)       = "□(" ++ show a ++ ")"
    show (LDiamond n a) = "◇≤" ++ show n ++ "("     ++ show a ++ ")"
    show (LAnd l r)     = show l ++ " ∧ " ++ show r
    show (LImplies l r) = show l ++ " ⇒ " ++ show r
    show (LNeg f)       = "¬(" ++ show f ++ ")"
    show (LOp s fs)     = s ++ "(" ++ (concat $ intersperse "," $ map show fs) ++ ")"
    show (LAtom s)      = s

-- Primes will be represented at the var level for now.
-- internal syntactic representation for (a subset of) TLA+ formulas
data TLAForm = TBox TLAForm 
             | TDiamond TLAForm 
             | TAnd TLAForm TLAForm 
             | TImplies TLAForm TLAForm 
             | TNeg TLAForm 
             | TAssign TLAVal TLAVal 
             | TLeq TLAVal TLAVal 
             | TOr TLAForm TLAForm 
             | TBool Bool 
             | TVal TLAVal 
    deriving Eq

instance Show TLAForm where
    show (TBox a)       = "[](" ++ show a ++ ")"
    show (TDiamond a)   = "<>(" ++ show a ++ ")"
    show (TNeg a)       = "~("  ++ show a ++ ")"
    show (TAnd l r)     = show l ++ " /\\ " ++ show r
    show (TOr l r)      = show l ++ " \\/ " ++ show r
    show (TImplies l r) = show l ++ " => "  ++ show r 
    show (TLeq l r)     = show l ++ " <= "  ++ show r 
    show (TAssign l r)  = show l ++ "' = "  ++ show r
    show (TVal t)       = show t
    show (TBool True)   = "TRUE"
    show (TBool False)  = "FALSE"

-- The distinction between value and formula is more to limit bugs while writing than something principled
-- This could easily be moved into the TLAForm type later
data TLAVal = TInt Int 
            | TFunc [(String,TLAVal)] 
            | TForm TLAForm 
            | TIf TLAForm TLAVal TLAVal 
            | TPlus TLAVal TLAVal
            | TVar String
            | TOp String [TLAVal]
            -- Only one that might not be self explanitory -- this is an application of a TLA+ function to a key.
            -- e.g (TApp (TVar "c") "foo") = c["foo"]
            | TApp TLAVal String 
    deriving Eq

instance Show TLAVal where
    show (TInt i)    = show i 
    show (TForm a)   = show a
    show (TIf f t e) = "(IF " ++ show f ++ " THEN " ++ show t ++ " ELSE " ++ show e ++ ")"
    show (TApp v s)  = show v ++ "[\"" ++ s ++ "\"]"
    show (TPlus v s) = "(" ++ show v ++ " + " ++ show s ++ ")"
    show (TVar s)    = s
    show (TOp s fs)  = s ++ "(" ++ (concat $ intersperse "," $ map show fs) ++ ")"
    --temp
    show (TFunc v)   = show v

depth :: LTLForm -> Int
depth (LBox f) = depth f
depth (LDiamond _ s) =  depth s
depth (LAnd f g) = 1 + max (depth f) (depth g)
depth (LImplies f g) = 1 + max (depth f) (depth g)
depth (LAtom _) = 0
-- TODO is this right for these purposes?
depth (LNeg f) = depth f

-- Counts the number of (bounded) diamonds in a wff.
-- Useful for determining if we need to compile a wff or can let TLA+ handle it.
diamonds :: LTLForm -> Int
diamonds (LBox f) = diamonds f
diamonds (LDiamond _ s) = 1 + diamonds s
diamonds (LAnd f g) = diamonds f + diamonds g
diamonds (LImplies f g) = diamonds f + diamonds g
diamonds (LNeg f) = diamonds f
diamonds (LAtom _) = 0

-- This repitition is bad and hacky. TODO.
boxes :: LTLForm -> Int
boxes (LBox f) = 1 + boxes f
boxes (LDiamond _ s) =  boxes s
boxes (LAnd f g) = boxes f + boxes g
boxes (LImplies f g) = boxes f + boxes g
boxes (LNeg f) = boxes f
boxes (LAtom _) = 0

-- Performs simplifications (that should all be tautological) of (PB)LTL formulas.
-- Reduces the number of cases we need to account for in compilation.
simplify :: LTLForm -> LTLForm
simplify (LBox (LDiamond n f)) = LDiamond n $ LBox $ simplify f
simplify (LBox (LBox  f)) =  simplify $ LBox f
simplify (LDiamond n (LDiamond m f)) = LDiamond (n+m) $ simplify f
simplify (f `LImplies` (g `LAnd` h)) = simplify ((f `LImplies` g)) `LAnd` (simplify (f `LImplies` h))
simplify (f `LImplies` (g `LImplies` h)) = simplify $ ((f `LAnd` g)) `LImplies` h
simplify (LBox (f `LAnd` g)) = (LBox $ simplify f) `LAnd` (LBox $ simplify g)
-- Not sure about this one... the has diamond constraint is on the right trail but might be overly conservative or overly liberal
simplify (LBox ((LBox f) `LImplies` g)) = if diamonds f == 0 then  (simplify $ LBox f) `LImplies` (simplify $ LBox g) else (LBox $ (simplify $ LBox f) `LImplies` simplify g)
simplify (f `LAnd` g) = (simplify f) `LAnd` (simplify g)
simplify (f `LImplies` g) = (simplify f) `LImplies` (simplify g)
simplify (LNeg f) = LNeg $ simplify f
simplify f = f

-- assumes pre-simplified formula
compileCondition' :: LTLForm -> CompM TLAForm
compileCondition' (LNeg f) = TNeg <$> compileCondition' f
compileCondition' (LAtom s) = pure $ TVal $ TVar s
compileCondition' (LImplies l r) = 
    if diamonds r > 0 
        then 
            --because its a pre-condition, all of the work for doing the antecedant gets moved to the next phase
            compileCondition' r
        else do
            l' <- compileCondition' l
            r' <- compileCondition' r
            pure $ l' `TImplies` r'
compileCondition' (LAnd l r) = do
    l' <- compileCondition' l
    r' <- compileCondition' r
    pure $ l' `TAnd` r'
-- don't need what's inside here, that gets used when determining how `truth m` gets updated in compileNext
compileCondition' (LDiamond n _) = do
    m <- getAndUpdate 
    pure $ TBox $ (counter m `TLeq` TInt n) `TOr` (TVal $ truth m)
compileCondition' (LBox s) = 
    if diamonds s > 0
        then 
            compileCondition' s
        else do
            r <- compileCondition' s
            pure $ TBox r

-- TODO deal with fairness later (genuinely does not seem bad, just extra)

compilePartialCondition :: LTLForm -> ([String],Int,Bool) -> TLAForm
compilePartialCondition f = fst . runState (compileCondition' f) 
compileCondition :: LTLForm -> TLAForm
compileCondition f = compilePartialCondition (simplify f) (names (simplify f),0,False)

-- This feels too simple... probably something I'm missing...
compileInit :: LTLForm -> CompM [TLAForm]
compileInit (LBox f) = compileInit f
compileInit (LAtom _) = pure []
compileInit (LNeg f) = compileInit f
compileInit (LAnd l r) = do
    l' <- compileInit l
    r' <- compileInit r
    pure $ l' ++ r'
compileInit (LImplies l r) =
    if diamonds r > 0
       -- TODO deal with left diamonds, too complex for now.
       then do
           name <- getAndUpdate
           -- This will generate the incorrect names if `l` has a diamond for now. 
           r' <- compileInit r
           d <- get
           pure $ (hp name `TAssign` (TForm $ compilePartialCondition l d)) : r'
       else do 
           l' <- compileInit l 
           r' <- compileInit r
           pure $ l' ++ r'
compileInit (LDiamond _ f) = 
    if depth f > 0 
       then error "diamond of composite wffs not yet implemented" 
       else do
           name <- getAndUpdate
           d <- get
           r <- compileInit f
           --TODO should this compilePartial advance the state?
           pure $ [hp name `TAssign` (TForm $ compilePartialCondition f d), counter name `TAssign` TInt 0] ++ r

-- I think this is where most of the complexity is...
compileNext :: LTLForm -> CompM [TLAForm]
compileNext (LAtom _) = pure []
-- Only case where this wouldn't work would be (Q => (<>(<=m)P/\<>(<=n)R)) or so, but this should have been transformed away in simplify.
compileNext (l `LAnd` r) = do 
    l' <- compileNext l 
    r' <- compileNext r
    pure $ l' ++ r'
compileNext (LDiamond _ (LBox f)) = do
    d <- get
    --TODO do we update here?
    name <- getAndUpdate
    let t = compilePartialCondition f d
    f' <- compileNext f
    pure $ (truth name `TAssign` TForm t ) 
            : TVal (TIf (TNeg $ TVal $ truth name) (TInt 0) (counter name `TPlus` TInt 1))
            : f'
compileNext (LDiamond _ f) = do
    d <- get
    --TODO do we update here?
    name <- getAndUpdate
    let t = compilePartialCondition f d
    f' <- compileNext f
    pure $ (truth name `TAssign` TForm (t `TOr` (TVal $ truth name))) 
            -- Need to know if we're inside a conditional under a box here.
            : (TVal (TIf (TNeg $ TVal $ truth name) (TInt 0) (counter name `TPlus` TInt 1)))
            : f'
compileNext (LBox f) =
    if diamonds f == 0 
       then pure []
       else error $ "should never occur (should have been simplified to <>[] or [](... => ...), or ([]p /\\ (<>)[]q))for wff: " ++ show (LBox f)
compileNext (l `LImplies` r) = do
    if diamonds l > 0 then error "Diamonds in left of implication not supported yet" else pure ()
    -- TODO messy. clean up.
    (names,i,h) <- get
    let name = names !! i
    let q = compilePartialCondition l (names,i,h)
    l' <- compileNext l
    if not h || diamonds r == 0
        then do
            r' <- compileNext r
            pure $ l' ++ r'
        else do
            dd <- get
            let p = compilePartialCondition r dd
            let nextHp = (hp name `TAssign` TForm ((TVal $ hp name) `TOr` q)) 
            let nextCounter  = counter name `TAssign` TIf (TNeg (TVal $ hp name)) 
                        (TInt 0) 
                        -- TODO Probably should be a direct match instead of `boxes`. Would be a quick refactor, but let's get this done first...
                        (if boxes r > 0 then (counter name) `TPlus` TInt 1 
                                        else (TIf ((TVal $ truth name) `TAnd` q ) (TInt 1) (counter name `TPlus` TInt 1)))
            let nextT = TAssign (truth name) $ if boxes r > 0 then TForm p else TForm ((TVal $ truth name) `TOr` p)
            r' <- compileNext r
            pure $ nextHp:nextCounter:nextT:r'
compileNext (LNeg f) = compileNext f

-- helpers..
counter :: String -> TLAVal 
counter s = (TApp (TApp (TVar "c") s) "counter")
truth :: String -> TLAVal
truth s = TApp (TApp (TVar "c") s) "t"
hp :: String -> TLAVal
hp s = TApp (TApp (TVar "c") s) "hp"

-- State Helpers

--Updates gets the current name for the counter and updates to the next one
getAndUpdate :: CompM String
getAndUpdate = get >>= \(ss,i,b) -> put (ss,i+1,b) >> pure (ss !! i)

getCurrentName :: CompM String
getCurrentName = get >>= \(ss,i,_) -> pure (ss !! i)

setBoxed :: CompM ()
setBoxed = get >>= \(ss,i,_) -> put (ss,i,True)

isBoxed :: CompM Bool
isBoxed = get >>= \(_,_, b) -> pure b

-- dumb name generator for counter.
-- Leads to terrible names, but is dead simple. Good enough for a prototype/MVP.
names :: LTLForm -> [String]
names f = take (diamonds f) $ iterate (++"prime") "temp"

--test examples
example :: LTLForm
example = LBox ((LAtom "q") `LImplies` LDiamond 20 (LAtom "p"))
example2 :: LTLForm
example2 = LBox ((LAtom "q") `LImplies` LDiamond 20 (LBox $ LAtom "p"))
example3 :: LTLForm
example3 = LBox ((LAtom "q") `LAnd` LDiamond 20 (LBox $ LAtom "p"))

d1 :: LTLForm
d1 = LDiamond 20 (LAtom "p")
d2 :: LTLForm
d2 = LDiamond 20 (LAtom "q" `LImplies` LAtom "p")
d3 :: LTLForm
d3 = LDiamond 25 $ LDiamond 20 $ LAtom "p"
d4 :: LTLForm
d4 = LAtom "q" `LImplies` (LDiamond 20 $ LAtom "p")
-- Much more to do here with actually getting this more cohesive, but right now just print each TLA+ Formula to console.
-- Need to still emit the addition of the variables and the fairness constraint (should just be WF_(NextP)? Have not thought that part out in depth)

parseString :: String -> IO LTLForm
parseString = undefined

main :: IO ()
main = do
    args <- getArgs
    form <- if null args then parseString =<< getContents else parseString =<< (readFile $ head args)
    undefined
